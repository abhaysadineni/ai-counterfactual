"""Public markets feed for abhaychakra.com/p/ai-counterfactual.

Pulls quarterly fundamentals for a fixed list of US filers from the SEC EDGAR company-facts API
(public domain) and macro series from FRED's public CSV endpoint (BEA, BLS and Federal Reserve series),
derives clean quarterly values, and writes one JSON file to the site bucket. Runs once a day.
No prices, no third-party licensed market data.
"""
import json, os, time, urllib.request, urllib.error, datetime, csv, io
import boto3

SITE_BUCKET = os.environ.get("SITE_BUCKET", "abhaychakra-com-site")
KEY = os.environ.get("OUT_KEY", "assets/data/markets.json")
UA = os.environ.get("SEC_UA", "abhaychakra.com AI Counterfactual markets module abhaychakra@berkeley.edu")
DIST = os.environ.get("DIST_ID", "")

COMPANIES = [
    # ticker, name, group
    ("MSFT", "Microsoft", "Hyperscalers"), ("GOOGL", "Alphabet", "Hyperscalers"), ("AMZN", "Amazon", "Hyperscalers"),
    ("META", "Meta Platforms", "Hyperscalers"), ("ORCL", "Oracle", "Hyperscalers"),
    ("NVDA", "NVIDIA", "Chips"), ("AMD", "AMD", "Chips"), ("AVGO", "Broadcom", "Chips"), ("INTC", "Intel", "Chips"),
    ("MU", "Micron", "Chips"), ("QCOM", "Qualcomm", "Chips"), ("MRVL", "Marvell", "Chips"),
    ("AMAT", "Applied Materials", "Equipment"), ("LRCX", "Lam Research", "Equipment"), ("KLAC", "KLA", "Equipment"),
    ("DELL", "Dell Technologies", "Infrastructure"), ("SMCI", "Super Micro Computer", "Infrastructure"),
    ("ANET", "Arista Networks", "Infrastructure"), ("VRT", "Vertiv", "Infrastructure"), ("EQIX", "Equinix", "Infrastructure"),
    ("CRM", "Salesforce", "Software"), ("NOW", "ServiceNow", "Software"), ("ADBE", "Adobe", "Software"),
    ("PLTR", "Palantir", "Software"), ("SNOW", "Snowflake", "Software"), ("IBM", "IBM", "Software"),
    ("CEG", "Constellation Energy", "Power"), ("VST", "Vistra", "Power"), ("GEV", "GE Vernova", "Power"),
]

TAGS = {
    "revenue": ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet", "RevenuesNetOfInterestExpense"],
    "opinc": ["OperatingIncomeLoss"],
    "rnd": ["ResearchAndDevelopmentExpense", "ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost"],
    "capex": ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets", "PaymentsToAcquirePropertyPlantAndEquipmentAndIntangibleAssets"],
    "netinc": ["NetIncomeLoss"],
    "ocf": ["NetCashProvidedByUsedInOperatingActivities"],
}

FRED = [
    ("B009RC1Q027SBEA", "Private fixed investment in information processing equipment", "billions of dollars, annual rate, quarterly", "BEA via FRED"),
    ("Y001RC1Q027SBEA", "Private fixed investment in intellectual property products", "billions of dollars, annual rate, quarterly", "BEA via FRED"),
    ("PNFI", "Private nonresidential fixed investment", "billions of dollars, annual rate, quarterly", "BEA via FRED"),
    ("OPHNFB", "Nonfarm business labour productivity", "index 2017 = 100, quarterly", "BLS via FRED"),
    ("FEDFUNDS", "Effective federal funds rate", "percent, monthly", "Federal Reserve via FRED"),
    ("DGS10", "10-year Treasury yield", "percent, daily", "Federal Reserve via FRED"),
    ("UNRATE", "Unemployment rate", "percent, monthly", "BLS via FRED"),
    ("CPIAUCSL", "Consumer price index, all urban consumers", "index 1982 to 1984 = 100, monthly", "BLS via FRED"),
]


def get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Encoding": "identity"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            time.sleep(1.5 * (i + 1))
        except Exception:
            time.sleep(1.5 * (i + 1))
    return None


def tickers_to_cik():
    raw = get("https://www.sec.gov/files/company_tickers.json")
    out = {}
    if raw:
        for v in json.loads(raw).values():
            out[v["ticker"].upper()] = (int(v["cik_str"]), v.get("title", ""))
    return out


def d(s):
    return datetime.date.fromisoformat(s)


def quarterly_one(node):
    """{end: (start, value)} of clean quarterly values from one tag node.
    Three-month facts are used directly; year-to-date facts (cash-flow style) are de-cumulated by
    subtracting the preceding fact that shares the same start date."""
    if not node or "USD" not in node.get("units", {}):
        return {}
    rows = [r for r in node["units"]["USD"] if r.get("start") and r.get("end") and r.get("form") in ("10-Q", "10-K", "10-Q/A", "10-K/A")]
    best = {}
    for r in rows:
        k = (r["start"], r["end"])
        if k not in best or r.get("filed", "") > best[k].get("filed", ""):
            best[k] = r
    by_start = {}
    for (s, e), r in best.items():
        by_start.setdefault(s, []).append((e, r["val"]))
    q = {}
    for s, lst in by_start.items():
        lst.sort()
        prev_val, prev_end = 0.0, None
        for e, v in lst:
            dur = (d(e) - d(s)).days
            if 75 <= dur <= 100:
                q[e] = (s, float(v))
            elif dur > 100 and prev_end is not None:
                gap = (d(e) - d(prev_end)).days
                if 75 <= gap <= 100:
                    q[e] = (prev_end, float(v) - float(prev_val))
            prev_val, prev_end = v, e
    return q


def find_tags(allfacts, tags, patterns):
    """us-gaap tags in order, then any company-specific tag whose name matches one of the patterns."""
    import re
    found = [("us-gaap", t) for t in tags if t in allfacts.get("us-gaap", {})]
    for taxo, node in allfacts.items():
        if taxo in ("us-gaap", "dei", "ifrs-full", "srt", "invest"):
            continue
        for t in node:
            if any(re.search(p, t) for p in patterns):
                found.append((taxo, t))
    return found


def quarterly(allfacts, tags, patterns):
    """Merge quarterly values across tags: earlier tags win where periods overlap."""
    merged, used = {}, []
    for taxo, t in find_tags(allfacts, tags, patterns):
        q = quarterly_one(allfacts[taxo][t])
        if not q:
            continue
        added = 0
        for e, sv in q.items():
            if e not in merged:
                merged[e] = sv
                added += 1
        if added:
            used.append(taxo + ":" + t)
    return used, dict(sorted(merged.items()))


PATTERNS = {
    "revenue": [r"^Revenue", r"Revenues$"],
    "opinc": [r"^OperatingIncome"],
    "rnd": [r"ResearchAndDevelopment"],
    "capex": [r"Purchases?OfPropertyAndEquipment", r"PaymentsToAcquireProperty", r"CapitalExpenditure", r"PurchasesOfPropertyPlantAndEquipment"],
    "netinc": [r"^NetIncomeLoss$"],
    "ocf": [r"NetCashProvidedByUsedInOperatingActivities"],
}


def quarter_label(start, end):
    a, b = d(start), d(end)
    mid = a + (b - a) / 2
    return "%dQ%d" % (mid.year, (mid.month - 1) // 3 + 1)


def company(ticker, name, group, cikmap):
    cik, title = cikmap.get(ticker, (None, None))
    if not cik:
        return None
    raw = get("https://data.sec.gov/api/xbrl/companyfacts/CIK%010d.json" % cik)
    if not raw:
        return None
    doc = json.loads(raw)
    allfacts = doc.get("facts", {})
    facts = allfacts.get("us-gaap", {})
    series, tags_used = {}, {}
    for key, tags in TAGS.items():
        used, q = quarterly(allfacts, tags, PATTERNS.get(key, []))
        if len(q) >= 8:
            lab = {}
            for e, (st, v) in q.items():
                l = quarter_label(st, e)
                if l not in lab or e > lab[l][0]:
                    lab[l] = (e, v)
            series[key] = [[l, ev[0], round(ev[1] / 1e6, 1)] for l, ev in sorted(lab.items(), key=lambda x: x[1][0])]
            tags_used[key] = used
    # latest filing reference: the most recently filed 10-Q or 10-K across every tag
    latest = None
    for tag, node in facts.items():
        for unit, rows in node.get("units", {}).items():
            for r in rows:
                if r.get("form") in ("10-Q", "10-K") and (latest is None or r.get("filed", "") > latest.get("filed", "")):
                    latest = {"form": r["form"], "filed": r["filed"], "accn": r["accn"], "fy": r.get("fy"), "fp": r.get("fp")}
    return {"ticker": ticker, "name": name, "group": group, "cik": cik, "entity": doc.get("entityName", title), "series": series, "tags": tags_used,
            "latestFiling": latest, "factsUrl": "https://data.sec.gov/api/xbrl/companyfacts/CIK%010d.json" % cik,
            "filingsUrl": "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=%010d&type=10-&dateb=&owner=include&count=40" % cik}


def fred(series_id):
    raw = get("https://fred.stlouisfed.org/graph/fredgraph.csv?id=%s" % series_id)
    if not raw:
        return []
    out = []
    for row in csv.DictReader(io.StringIO(raw.decode("utf-8", "replace"))):
        v = row.get(series_id) or row.get("VALUE")
        dt = row.get("observation_date") or row.get("DATE")
        if v in (None, ".", "") or not dt:
            continue
        try:
            out.append([dt, float(v)])
        except ValueError:
            pass
    return out


def handler(event, context):
    t0 = time.time()
    cikmap = tickers_to_cik()
    companies, failures = [], []
    for ticker, name, group in COMPANIES:
        try:
            c = company(ticker, name, group, cikmap)
            if c and c["series"]:
                companies.append(c)
            else:
                failures.append(ticker)
        except Exception as e:
            failures.append("%s:%s" % (ticker, str(e)[:80]))
        time.sleep(0.15)
    macro = {}
    for sid, title, units, source in FRED:
        pts = fred(sid)
        if pts:
            # thin daily series to weekly
            if len(pts) > 3000:
                pts = pts[::5]
            macro[sid] = {"title": title, "units": units, "source": source, "url": "https://fred.stlouisfed.org/series/" + sid, "points": pts[-1200:]}
    out = {"generated": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z", "seconds": round(time.time() - t0, 1),
           "sources": [{"name": "SEC EDGAR company facts API", "url": "https://www.sec.gov/edgar/sec-api-documentation", "licence": "United States government work, public domain", "note": "Quarterly values derived from 10-Q and 10-K XBRL facts; year-to-date cash-flow items de-cumulated; fiscal quarters mapped to the nearest calendar quarter."},
                       {"name": "FRED, Federal Reserve Bank of St. Louis", "url": "https://fred.stlouisfed.org/", "licence": "BEA, BLS and Federal Reserve series are public domain; FRED asks for attribution", "note": "Series pulled from the public CSV endpoint."}],
           "companies": companies, "failures": failures, "macro": macro}
    body = json.dumps(out, separators=(",", ":"))
    s3 = boto3.client("s3")
    s3.put_object(Bucket=SITE_BUCKET, Key=KEY, Body=body.encode("utf-8"), ContentType="application/json", CacheControl="public, max-age=900")
    if DIST:
        try:
            boto3.client("cloudfront").create_invalidation(DistributionId=DIST, InvalidationBatch={"Paths": {"Quantity": 1, "Items": ["/" + KEY]}, "CallerReference": str(time.time())})
        except Exception:
            pass
    return {"ok": True, "companies": len(companies), "failures": failures, "macro": list(macro.keys()), "bytes": len(body), "seconds": out["seconds"]}
